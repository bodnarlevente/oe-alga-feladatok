﻿# Tudnivalók a projekttel kapcsolatban
- A félév során elkészítendő feladatokhoz tartozó fájlok a megadott mappában létre vannak hozva.
- A megoldást minden esetben a fájlon belül lévő névtérbe kell elkészíteni.
- A fejlesztés során az adott feladathoz tartozó teszt fájl (például: *Tesztek/01_ImperativParadigmaTesztek.cs*) tartalma legyen futtatható (*Ctrl+A*, majd *Ctrl+K+U*).
- Későbbi hetek feladatai felhasználhatják egy korábbi hét feladatának megoldását, így érdemes a korábbi teszteket is folyamatosan figyelemmel kísérni, mivel azoknak továbbra is hibátlanul le kell futniuk.
- A teszteknél hiányzó *IVegrehajthato* és *IFuggo* interfészek elkészítése az első hét feladata.
